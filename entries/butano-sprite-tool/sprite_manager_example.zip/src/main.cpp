#include "bn_bg_palettes.h"
#include "bn_core.h"
#include "bn_display.h"
#include "bn_fixed_point.h"
#include "bn_keypad.h"
#include "bn_sprite_animate_actions.h"
#include "bn_sprite_text_generator.h"

#include "common_info.h"
#include "common_variable_8x16_sprite_font.h"

#include "mc_manager_animation_animation_example_1.hpp"
#include "mc_manager_animation_animation_example_1_max_frames.hpp"
#include "mc_manager_animation_animation_example_1_types.hpp"

namespace {
    void default_sprite_scene(bn::sprite_text_generator& text_generator) {
        constexpr bn::string_view info_text_lines[] = {
            "START: go to next scene",
        };

        common::info info("Default sprite", info_text_lines, text_generator);

        bn::sprite_ptr ninja = mc::manager_animation::animation_example_1::default_sprite(bn::fixed_point(0, 0));

        while (!bn::keypad::start_pressed()) {
            info.update();
            bn::core::update();
        }
    }

    void animation_forever_scene(bn::sprite_text_generator& text_generator) {
        constexpr bn::string_view info_text_lines[] = {
            "START: go to next scene",
        };

        common::info info("Animation forever", info_text_lines, text_generator);

        bn::sprite_ptr ninja = mc::manager_animation::animation_example_1::default_sprite(bn::fixed_point(0, 0));

        mc::manager_animation::animation_example_1::animation animation;

        mc::manager_animation::animation_example_1::animation_forever(ninja, animation);

        while (!bn::keypad::start_pressed()) {
            animation->update();

            info.update();
            bn::core::update();
        }
    }

    void animation_once_scene(bn::sprite_text_generator& text_generator) {
        constexpr bn::string_view info_text_lines[] = {
            "A: restart animation",
            "",
            "START: go to next scene",
        };

        common::info info("Animation once", info_text_lines, text_generator);

        bn::sprite_ptr ninja = mc::manager_animation::animation_example_1::default_sprite(bn::fixed_point(0, 0));

        mc::manager_animation::animation_example_1::animation animation;

        mc::manager_animation::animation_example_1::animation_once(ninja, animation);

        while (!bn::keypad::start_pressed()) {
            if (!animation->done()) {
                animation->update();
            }

            if (bn::keypad::a_pressed()) {
                mc::manager_animation::animation_example_1::animation_once(ninja, animation);
            }
            info.update();
            bn::core::update();
        }
    }

    void sprite_flip_scene(bn::sprite_text_generator& text_generator) {
        constexpr bn::string_view info_text_lines[] = {
            "START: go to next scene",
        };

        common::info info("Sprite flip", info_text_lines, text_generator);

        bn::sprite_ptr ninja = mc::manager_animation::animation_example_1::default_sprite(bn::fixed_point(0, 0));

        mc::manager_animation::animation_example_1::animation animation;

        mc::manager_animation::animation_example_1::animation_sprite_flip(ninja, animation);

        while (!bn::keypad::start_pressed()) {
            animation->update();
            info.update();
            bn::core::update();
        }
    }

    void sprite_change_animation_scene(bn::sprite_text_generator& text_generator) {
        constexpr bn::string_view info_text_lines[] = {
            "PAD: change sprite's direction",
            "",
            "START: go to next scene",
        };

        common::info info("Sprite change animation", info_text_lines, text_generator);

        bn::sprite_ptr ninja = mc::manager_animation::animation_example_1::default_sprite(bn::fixed_point(0, 0));

        mc::manager_animation::animation_example_1::animation animation;

        mc::manager_animation::animation_example_1::bottom(ninja, animation);

        while (!bn::keypad::start_pressed()) {
            if (bn::keypad::down_pressed()) {
                mc::manager_animation::animation_example_1::bottom(ninja, animation);
            }
            if (bn::keypad::up_pressed()) {
                mc::manager_animation::animation_example_1::top(ninja, animation);
            }
            if (bn::keypad::left_pressed()) {
                mc::manager_animation::animation_example_1::left(ninja, animation);
            }
            if (bn::keypad::right_pressed()) {
                mc::manager_animation::animation_example_1::right(ninja, animation);
            }

            animation->update();
            info.update();
            bn::core::update();
        }
    }

    void sprite_animation_array_scene(bn::sprite_text_generator& text_generator) {
        constexpr bn::string_view info_text_lines[] = {
            "PAD: change sprite's direction",
            "",
            "START: go to next scene",
        };

        common::info info("Animation array", info_text_lines, text_generator);

        bn::sprite_ptr ninja = mc::manager_animation::animation_example_1::default_sprite(bn::fixed_point(0, 0));

        mc::manager_animation::animation_example_1::animation animation;

        mc::manager_animation::animation_example_1::animation_array<4> animation_array{
            mc::manager_animation::animation_example_1::bottom, mc::manager_animation::animation_example_1::top,
            mc::manager_animation::animation_example_1::left, mc::manager_animation::animation_example_1::right};

        int dir = 0;

        animation_array[dir](ninja, animation);

        while (!bn::keypad::start_pressed()) {
            if (bn::keypad::down_pressed()) {
                dir = 0;
            }
            if (bn::keypad::up_pressed()) {
                dir = 1;
            }
            if (bn::keypad::left_pressed()) {
                dir = 2;
            }
            if (bn::keypad::right_pressed()) {
                dir = 3;
            }

            if (bn::keypad::any_pressed()) {
                animation_array[dir](ninja, animation);
            }

            animation->update();
            info.update();
            bn::core::update();
        }
    }
}  // namespace

int main() {
    bn::core::init();

    bn::sprite_text_generator text_generator(common::variable_8x16_sprite_font);
    bn::bg_palettes::set_transparent_color(bn::color(16, 16, 16));

    while (true) {
        default_sprite_scene(text_generator);
        bn::core::update();

        animation_forever_scene(text_generator);
        bn::core::update();

        animation_once_scene(text_generator);
        bn::core::update();

        sprite_flip_scene(text_generator);
        bn::core::update();

        sprite_change_animation_scene(text_generator);
        bn::core::update();

        sprite_animation_array_scene(text_generator);
        bn::core::update();
    }
}